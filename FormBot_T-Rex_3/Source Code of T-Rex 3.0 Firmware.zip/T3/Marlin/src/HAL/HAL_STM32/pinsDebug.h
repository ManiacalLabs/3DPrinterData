#error "Debug pins is not yet supported for STM32!"
